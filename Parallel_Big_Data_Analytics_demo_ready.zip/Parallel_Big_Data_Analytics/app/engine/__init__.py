"""Native compute engine package."""
